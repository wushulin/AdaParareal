clc;
clear;
global mu dx gam Tol NTmax PTol dtmin dtmax
Kmax=20;
NTmax=5000;
mu=0.01;
PTol=1e-10;
Tol=1e-12;
gam=(3+sqrt(3))/6;
gam=(2+sqrt(2))/2;
dtmin=1/100;
dtmax=1/10;
T=50;
dx=1/128;
cdt=1/2;
Nt=T/cdt;
fNt=1e+6;
xx=(-1:dx:1)';
Nx=length(xx)-2;
x=xx(2:Nx+1);
It=eye(Nt);
Ix=eye(Nx);
e=ones(Nx,1);
A=-spdiags([e,-2*e,e]/dx^2,[-1,0,1],Nx,Nx);
u0=0.53*x+0.47*sin(-1.5*pi*x);
U_f=zeros(Nx,fNt+1);
U_fb=zeros(Nx+2,fNt+1);
U_fb(:,1)=[-1;u0;1];
U_f(:,1)=u0;
Eng=zeros(1,fNt+1);
var_dt=zeros(1,fNt+1);
n=1;
Eng(n)=EngU(U_fb(:,n));
flag=1;
for n=1:fNt
    if n==1
        fdt=dtmin;
        var_dt(n)=fdt;
        U_f(:,n+1)=Prof_BE(U_f(:,n),fdt,A);
        U_fb(:,n+1)=[-1;U_f(:,n+1);1];
        Eng(n+1)=EngU(U_fb(:,n));
    else
        if abs(sum(var_dt(1:n))-T)<=dtmax && abs(sum(var_dt(1:n))-T)>=dtmin
            fdt=abs(sum(var_dt(1:n))-T);
            flag=0;
        else
            fdt=max(dtmin,dtmax/sqrt(1+10^5*abs(Eng(n)-Eng(n-1))/fdt));
        end
        var_dt(n)=fdt;
        U_f(:,n+1)=Prof_BE(U_f(:,n),fdt,A);
        U_fb(:,n+1)=[-1;U_f(:,n+1);1];
        Eng(n+1)=EngU(U_fb(:,n));
    end
    if flag==0
        break;
    end
end
fNt=n;
% plot(linspace(0,T,fNt+1),Eng(1:fNt+1),'+');shg
 
% Uk=random('unif',-1,1,Nx,Nt+1);
% Uk(:,1)=u0;
% Uk1=Uk;
% Err=zeros(1,Kmax);
% for k=1:Kmax
%     JJ=randi([4,16],1,Nt);
%     Fk=zeros(Nx,Nt+1);
%     PUk=zeros(Nx,Nt+1);
%     PUk(:,1)=u0;
%     for n=1:Nt
%         J=4;
%         dt0=random('unif',0,1,J);
%         dtt=dt0/sum(dt0)*cdt;
%         z0=Uk(:,n);
%         v0=PUk(:,n);
%         for p=1:J
%             fdt=dtt(p);
%             %fdt=cdt/J;
%              z0=Prof_SDIRK(z0,fdt,A);
%              v0=Prof_SDIRK(v0,fdt,A);
%         end
%         Fk(:,n+1)=z0;
%         PUk(:,n+1)=v0;
%     end
%     for n=1:Nt
%         Uk1(:,n+1)=Prof_BE(Uk1(:,n),cdt,A)+Fk(:,n+1)-Prof_BE(Uk(:,n),cdt,A); 
%     end
%     Err(k)=max(max(abs(Uk1-PUk)));
%     Uk=Uk1;
%     fprintf('---------%d-th iteration: error=%2.13f--------\n',k,Err(k));
%     if Err(k)<=PTol
%         break;
%     end
% end
% d=1;
% semilogy(1:d:k,Err(1:d:k),'b-o','linewidth',1,'markersize',9);shg
% set(gca,'fontsize',13,'fontname','times new roman');
% xlabel('Iteration Index $k$','interpreter','latex','fontsize',19);
% ylabel('Error','interpreter','latex','fontsize',19);
% set(gca,'ytick',10.^(-12:2:0));
% ylim([Tol,2]);
% % title('non-uniform fine time grids and $\nu=1$','interpreter','latex','fontsize',20);
% % leg=legend('3rd-order SDIRK','2nd-order SDIRK ($\gamma=\frac{2-\sqrt{2}}{2}$)','2nd-order SDIRK ($\gamma=\frac{2+\sqrt{2}}{2}$)');
% % set(leg,'interpreter','latex','fontsize',14);




function val=Prof_TR(u,dt,A)
       global mu dx Tol NTmax
       Nx=2/dx-1;
       Ix=eye(Nx);
       b0=mu*[-1;zeros(Nx-2,1);1]/dx^2;
       b=u-0.5*mu*dt*A*u-0.5*dt*f(u)+dt*b0;
       z0=u;
       for k=1:NTmax
            Jac=Ix+0.5*dt*mu*A+0.5*dt*df(z0);
            res=(Ix+0.5*dt*mu*A)*z0+0.5*dt*f(z0)-b;
            if norm(res,inf)<=Tol
                val=z0;
                break;
            else
                z0=z0-Jac\res;
            end
       end
end
function val=Prof_SDIRK(u,dt,A)
       global mu dx Tol NTmax gam
       Nx=2/dx-1;
       Ix=eye(Nx);
       b0=mu*[-1;zeros(Nx-2,1);1]/dx^2;
        if gam==(3+sqrt(3))/6
            b=0.5;
            tgam=(0.5-gam*b)/(1-b)-gam;
        else
            b=1-gam;
            tgam=(0.5-gam*b)/(1-b)-gam;
        end
        b1=b0-mu*A*u;
        z0=u;
        for k=1:NTmax
            Jac=Ix+dt*mu*gam*A+dt*gam*df(u+dt*gam*z0);
            res=(Ix+dt*mu*gam*A)*z0+f(u+dt*gam*z0)-b1;
            if norm(res,inf)<=Tol
                break;
            else
                z0=z0-Jac\res;
            end
        end
        k1=z0;
        b2=b0-mu*A*u-dt*tgam*mu*A*k1;
        for k=1:NTmax
            Jac=Ix+dt*mu*gam*A+dt*gam*df(u+dt*tgam*k1+dt*gam*z0);
            res=(Ix+dt*mu*gam*A)*z0+f(u+dt*tgam*k1+dt*gam*z0)-b2;
            if norm(res,inf)<=Tol
                break;
            else
                z0=z0-Jac\res;
            end
        end
        k2=z0;
        val=u+dt*b*k1+dt*(1-b)*k2;
end
 

function val=Prof_BE(u,dt,A)
       global mu dx Tol NTmax
       Nx=2/dx-1;
       Ix=eye(Nx);
       b0=mu*[-1;zeros(Nx-2,1);1]/dx^2;
       b=u+dt*b0;
       z0=u;
       for k=1:NTmax
            Jac=Ix+dt*mu*A+dt*df(z0);
            res=(Ix+dt*mu*A)*z0+dt*f(z0)-b;
            z1=z0-Jac\res;
            if norm(z1-z0,inf)<=Tol
                val=z1;
                break;
            else
                z0=z1;
            end
       end
end

function val=f(u)
val=u.^3-u;
end

function val=df(u)
val=3*diag(u.^2)-eye(length(u));
end

function val=EngU(u)
    global dx mu 
    Nx=length(u)-2;
    c=0;
    for j=2:Nx+1
        c=c+(1/dx)*(mu/8)*(u(j+1)-u(j-1))^2+dx*((u(j+1)^2-1)^2+(u(j-1)^2-1)^2)/8;
    end
    val=c;
end