clc;
clear;
global mu dx gam Tol NTmax PTol dtmin dtmax 
flag_Uf=0;
flag_parareal=1;
Kmax=30;
NTmax=5000;
mu=0.01;
PTol=1e-10;
Tol=1e-13;
gam=(3+sqrt(3))/6;
%gam=(2+sqrt(2))/2;
dtmin=1/100;
dtmax=1/8;
T=25;
dx=1/64;
cdt=1/2;
Nt=T/cdt;
fNt=ceil(T/dtmin)*2;
xx=(-1:dx:1)';
Nx=length(xx)-2;
x=xx(2:Nx+1);
It=eye(Nt);
Ix=eye(Nx);
e=ones(Nx,1);
A=-spdiags([e,-2*e,e]/dx^2,[-1,0,1],Nx,Nx);
u0=0.53*x+0.47*sin(-1.5*pi*x);

if flag_Uf==1
    U_f=zeros(Nx,fNt+1);
    U_f(:,1)=u0;
    Eng=zeros(1,fNt+1);
    var_dt=zeros(1,fNt+1);
    n=1;
    Eng(n)=EngU([-1;U_f(:,n);1]);
    flag=1;
    for n=1:fNt
        if n==1
            fdt=dtmin;
        end
        u1=Prof_BE(U_f(:,n),fdt,A);
        Eng0=EngU([-1;U_f(:,n);1]);
        Eng1=EngU([-1;u1;1]);
        fdt=max(dtmin,dtmax/sqrt(1+10^5*abs(Eng1-Eng0)/fdt));
        if abs(sum(var_dt(1:n))-T)<=dtmax && abs(sum(var_dt(1:n))-T)>=dtmin
            fdt=abs(sum(var_dt(1:n))-T);
            flag=0;
        end
        var_dt(n)=fdt;
        U_f(:,n+1)=Prof_BE(U_f(:,n),fdt,A);
        Eng(n+1)=EngU([-1;U_f(:,n+1);1]);
        if flag==0
            break;
        end
    end
    fNt=n;
%     plot(linspace(0,T,fNt),var_dt(1:fNt),'b+','linewidth',0.5);shg
%     set(gca,'fontsize',13,'fontname','times new roman');
%     xlabel('Time: $t$','interpreter','latex','fontsize',19);
%     ylabel('Energy $E(t)$','interpreter','latex','fontsize',19);
%     ylim([0,0.1]);
%     surf(linspace(0,T,fNt/10+1),x,U_f(:,1:10:fNt+1));shg
%     shading interp;
%     light('position',[0,-10,1.5],'style','infinite');
%     lighting phong;
%     material shiny;
%     set(gca,'fontsize',13,'fontname','times new roman');
%     xlabel('Time: $t$','interpreter','latex','fontsize',19);
%     ylabel('Space: $x$','interpreter','latex','fontsize',19);
%     zlabel('$u$','interpreter','latex','fontsize',19);
    %set(gca,'ytick',10.^(-12:2:0));
    %ylim([Tol,2]);
    %title('non-uniform fine time grids and $\nu=1$','interpreter','latex','fontsize',20);
    %leg=legend('3rd-order SDIRK','2nd-order SDIRK ($\gamma=\frac{2-\sqrt{2}}{2}$)','2nd-order SDIRK ($\gamma=\frac{2+\sqrt{2}}{2}$)');
    %set(leg,'interpreter','latex','fontsize',14);

end
if flag_parareal==1
    Jkmax=ceil(cdt/dtmin)*2;
    Uk=random('unif',-1,1,Nx,Nt+1);
    Uk(:,1)=u0;
    Uk1=Uk;
    Err=zeros(1,Kmax);
    Jk=zeros(Nt,Kmax);
    Var_dt_k=zeros(Nt,Jkmax,Kmax);

    for k=1:Kmax
        Fk=zeros(Nx,Nt+1);
        PUk=zeros(Nx,Nt+1);
        PUk(:,1)=u0;
        for n=1:Nt
            z0=Uk(:,n);
            v0=PUk(:,n);        
            flag=1;
            for j=1:Jkmax
                Eng0=EngU([-1;z0;1]);
                if j==1
                    fdt=dtmin;
                end
                z1=Prof_BE(z0,fdt,A);
                Eng1=EngU([-1;z1;1]);
                fdt=max(dtmin,dtmax/sqrt(1+10^5*abs(Eng1-Eng0)/fdt)); 
                Var_dt_k(n,j,k)=fdt;
                if abs(sum(Var_dt_k(n,1:j,k))-cdt)<=dtmax && abs(sum(Var_dt_k(n,1:j,k))-cdt)>=dtmin
                    fdt=abs(sum(Var_dt_k(n,1:j,k))-cdt);
                    flag=0;
                end
                Var_dt_k(n,j,k)=fdt;
                z0=Prof_BE(z0,fdt,A);
                v0=Prof_BE(v0,fdt,A);
                if flag==0
                    break;
                end
            end
            Jk(n,k)=j;
            Fk(:,n+1)=z0;
            PUk(:,n+1)=v0;
        end
        for n=1:Nt
            Uk1(:,n+1)=Prof_BE(Uk1(:,n),cdt,A)+Fk(:,n+1)-Prof_BE(Uk(:,n),cdt,A); 
        end
        Err(k)=max(max(abs(Uk1-PUk)));
        Uk=Uk1;
        fprintf('---------%d-th iteration: error=%2.13f--------\n',k,Err(k));
        if Err(k)<=PTol
            break;
        end
    end
    K=k;
    
    k=3;
    figure(1);
    for n=1:Nt
        plot(linspace((n-1)*cdt,n*cdt,Jk(n,k)),Var_dt_k(n,1:Jk(n,k),k),'b+');
        hold on;
    end
    hold off;
    set(gca,'fontsize',13,'fontname','times new roman');
    xlabel('Time: $t$','interpreter','latex','fontsize',19);
    ylabel('$\Delta t_n$','interpreter','latex','fontsize',19);
    ylim([0,dtmax+0.01]);
     title('After 1 iteration','fontsize',19);
    set(gca,'ytick',[0.01,0.03,0.05,0.07,0.09,0.11,0.13]);
    figure(3);
    plot(1:Nt,Jk(:,k),'r+','markersize',9);shg
    set(gca,'fontsize',13,'fontname','times new roman');
    xlabel('Index of Large Subinterval: $n$','interpreter','latex','fontsize',18);
    ylabel('Number of fine time steps: $J_n$','interpreter','latex','fontsize',18);
    ylim([0,100]);
    set(gca,'ytick',0:10:100);
    title('After 1 iteration','fontsize',19);
    
%     figure(2);
%     d=1;
%     semilogy(5:d:K,Err(5:d:K),'b-o','linewidth',1,'markersize',9);shg
%     xlabel('Iteration Index $k$','interpreter','latex','fontsize',19);
%     ylabel('Error','interpreter','latex','fontsize',19);
%     set(gca,'ytick',10.^(-12:2:0));
%     ylim([Tol,2]);
%     


end

% % title('non-uniform fine time grids and $\nu=1$','interpreter','latex','fontsize',20);
% % leg=legend('3rd-order SDIRK','2nd-order SDIRK ($\gamma=\frac{2-\sqrt{2}}{2}$)','2nd-order SDIRK ($\gamma=\frac{2+\sqrt{2}}{2}$)');
% % set(leg,'interpreter','latex','fontsize',14);




function val=Prof_TR(u,dt,A)
       global mu dx Tol NTmax
       Nx=2/dx-1;
       Ix=eye(Nx);
       b0=mu*[-1;zeros(Nx-2,1);1]/dx^2;
       b=u-0.5*mu*dt*A*u-0.5*dt*f(u)+dt*b0;
       z0=u;
       for k=1:NTmax
            Jac=Ix+0.5*dt*mu*A+0.5*dt*df(z0);
            res=(Ix+0.5*dt*mu*A)*z0+0.5*dt*f(z0)-b;
            if norm(res,inf)<=Tol
                val=z0;
                break;
            else
                z0=z0-Jac\res;
            end
       end
end
function val=Prof_SDIRK(u,dt,A)
       global mu dx Tol NTmax gam
       Nx=2/dx-1;
       Ix=eye(Nx);
       b0=mu*[-1;zeros(Nx-2,1);1]/dx^2;
        if gam==(3+sqrt(3))/6
            b=0.5;
            tgam=(0.5-gam*b)/(1-b)-gam;
        else
            b=1-gam;
            tgam=(0.5-gam*b)/(1-b)-gam;
        end
        b1=b0-mu*A*u;
        z0=u;
        for k=1:NTmax
            Jac=Ix+dt*mu*gam*A+dt*gam*df(u+dt*gam*z0);
            res=(Ix+dt*mu*gam*A)*z0+f(u+dt*gam*z0)-b1;
            if norm(res,inf)<=Tol
                break;
            else
                z0=z0-Jac\res;
            end
        end
        k1=z0;
        b2=b0-mu*A*u-dt*tgam*mu*A*k1;
        for k=1:NTmax
            Jac=Ix+dt*mu*gam*A+dt*gam*df(u+dt*tgam*k1+dt*gam*z0);
            res=(Ix+dt*mu*gam*A)*z0+f(u+dt*tgam*k1+dt*gam*z0)-b2;
            if norm(res,inf)<=Tol
                break;
            else
                z0=z0-Jac\res;
            end
        end
        k2=z0;
        val=u+dt*b*k1+dt*(1-b)*k2;
end
 

function val=Prof_BE(u,dt,A)
       global mu dx Tol NTmax
       Nx=2/dx-1;
       Ix=eye(Nx);
       b0=mu*[-1;zeros(Nx-2,1);1]/dx^2;
       b=u+dt*b0;
       z0=u;
       for k=1:NTmax
            Jac=Ix+dt*mu*A+dt*df(z0);
            res=(Ix+dt*mu*A)*z0+dt*f(z0)-b;
            z1=z0-Jac\res;
            if norm(z1-z0,inf)<=Tol
                val=z1;
                break;
            else
                z0=z1;
            end
       end
end

function val=f(u)
val=u.^3-u;
end

function val=df(u)
val=3*diag(u.^2)-eye(length(u));
end

function val=EngU(u)
    global dx mu 
    Nx=length(u)-2;
    c=0;
    for j=2:Nx+1
        c=c+(1/dx)*(mu/8)*(u(j+1)-u(j-1))^2+dx*((u(j+1)^2-1)^2+(u(j-1)^2-1)^2)/8;
    end
    val=c;
end