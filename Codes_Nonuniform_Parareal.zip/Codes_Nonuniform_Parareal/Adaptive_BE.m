function [tau_n,t,SolU,res_max,it_max]=Adaptive_BE(T0,T1,U0,tau0,A,PK_Num,PK_Tol,c,flag_display)
% T0: start time point
% T1: finial time point
% U0: initial solution of the ODEs at t=T0
% tau0: initial step-size (reduced by a half if step-size-rejection happens)
SolU=[U0];
n=1;
t=[T0];
tau=tau0;
res_max=0;
it_max=0;
while max(t)<T1
    [res,iter,z0]=PK_Solver(SolU(:,n),SolU(:,n),tau*A,PK_Num,PK_Tol,c);
    if res<=PK_Tol && iter<=PK_Num
        res_max=max(res,res_max);
        it_max=max(iter,it_max);
        n=n+1;
        SolU=[SolU,z0];
        t=[t,max(t)+tau];
        tau_n(n-1)=tau;
        if flag_display==1
            fprintf('n=%d: t=%2.4f, tau=%2.4f\n',n,max(t),tau);
        end
        tau=min(T1-max(t),tau0); % ����һ������ĳ�ʼ������λ
    else
        tau=tau/2;
        if flag_display==1
            fprintf('-------step-size rejection at %d-th step---------\n', n);
        end
        if tau<=1e-5
            if flag_display==1
                fprintf('***** Step-size is TOO small !*****\n');
            end
            break;
        end
    end
end
