clc;
clear;
nu=0.49;
Kmax=30;
global flag_SDIRK
Tol=1e-12;
T=16;
h=1/50;
cdt=1/16; 
J=16;
fdt=cdt/J;
Nt=T/cdt;
Nx1D=1/h+1;
It=eye(Nt);
Ix=eye(Nx1D);
e=ones(Nx1D,1);
A1=spdiags([e,-2*e,e]/h^2,[-1,0,1],Nx1D,Nx1D);
A2=spdiags([-e,0*e,e]/(h*2),[-1,0,1],Nx1D,Nx1D);
A1(1,Nx1D)=1/h^2;
A1(Nx1D,1)=A1(1,Nx1D);
A2(1,Nx1D)=-1/(2*h);
A2(Nx1D,1)=-A2(1,Nx1D);
AA=A2-nu*A1;
A=kron(Ix,AA)+kron(AA,Ix);
Nx=max(size(A));
Ix=eye(Nx);
invAc=Ix/(Ix+cdt*A);
x=(0:h:1)';
uu0=zeros(Nx1D,Nx1D);
for jx=1:Nx1D
    for jy=1:Nx1D
        uu0(jx,jy)=sin(2*pi*x(jx))*sin(2*pi*x(jy));
    end
end
u0=reshape(uu0,Nx,1);
U_Ini=random('unif',-1,1,Nx,Nt+1);
U_Ini(:,1)=u0;
U_ref=zeros(Nx,Nt+1);
U_ref(:,1)=u0;
%---parareal using F=SDIRK2(a)----
flag_SDIRK='2a';
Uk=U_Ini;
Uk1=Uk;
Err_2a=zeros(1,Kmax);
U_ref_2a=zeros(Nx,Nt+1);
U_ref_2a(:,1)=u0;
for n=1:Nt
    w0=U_ref_2a(:,n); 
    for p=1:J
        w0=Pro_F(A,fdt,w0,flag_SDIRK);
    end
    U_ref_2a(:,n+1)=w0;
end
k=1;
Err_2a(k)=max(max(abs(Uk1-U_ref_2a)));
fprintf('---------F=SDIRK2(a): %d-th iteration, error=%2.13f--------\n',k,Err_2a(k));
for k=1:Kmax
    Fk=zeros(Nx,Nt+1);
    for n=k:Nt
        z0=Uk(:,n);
        for p=1:J
            z0=Pro_F(A,fdt,z0,flag_SDIRK);
        end
        Fk(:,n+1)=z0;
    end
    for n=k:Nt
        Uk1(:,n+1)=invAc*(Uk1(:,n)-Uk(:,n))+Fk(:,n+1);
    end
    Err_2a(k+1)=max(max(abs(Uk1-U_ref_2a)));
    Uk=Uk1;
    fprintf('---------F=SDIRK2(a): %d-th iteration, error=%2.13f--------\n',k+1,Err_2a(k+1));
    if Err_2a(k+1)<=Tol
        break;
    end
end
It_Num_2a=k+1;
%---parareal using F=SDIRK2(b)----
flag_SDIRK='2b';
Uk=U_Ini;
Uk1=Uk;
Err_2b=zeros(1,Kmax);
U_ref_2b=zeros(Nx,Nt+1);
U_ref_2b(:,1)=u0;
for n=1:Nt
    w0=U_ref_2b(:,n); 
    for p=1:J
        w0=Pro_F(A,fdt,w0,flag_SDIRK);
    end
    U_ref_2b(:,n+1)=w0;
end
k=1;
Err_2b(k)=max(max(abs(Uk1-U_ref_2b)));
fprintf('---------F=SDIRK2(b): %d-th iteration, error=%2.13f--------\n',k,Err_2b(k));
for k=1:Kmax
    Fk=zeros(Nx,Nt+1);
    for n=k:Nt
        z0=Uk(:,n);
        for p=1:J
            z0=Pro_F(A,fdt,z0,flag_SDIRK);
        end
        Fk(:,n+1)=z0;
    end
    for n=k:Nt
        Uk1(:,n+1)=invAc*(Uk1(:,n)-Uk(:,n))+Fk(:,n+1);
    end
    Err_2b(k+1)=max(max(abs(Uk1-U_ref_2b)));
    Uk=Uk1;
    fprintf('---------F=SDIRK2(b): %d-th iteration, error=%2.13f--------\n',k+1,Err_2b(k+1));
    if Err_2b(k+1)<=Tol
        break;
    end
end
It_Num_2b=k+1;
d=1;
semilogy(1:d:It_Num_2b,Err_2b(1:d:It_Num_2b),'r-o',1:d:It_Num_2a,Err_2a(1:d:It_Num_2a),'b--s','linewidth',1,'markersize',9);shg
set(gca,'fontsize',13,'fontname','times new roman');
xlabel('Iteration Index $k$','interpreter','latex','fontsize',20);
ylabel('Error','fontsize',20);
set(gca,'ytick',10.^(-12:1:0));
set(gca,'xtick',1:2:27);
ylim([Tol,2]);
xlim([1,27]);
title('uniform fine time grids and sequential CGC','fontsize',20);
leg=legend('SDIRK2(b)','SDIRK2(a)');
set(leg,'interpreter','latex','fontsize',14);

function val=Pro_F(A,fdt,un,flag_SDIRK)    
Ix=eye(length(un));
if strcmp(flag_SDIRK,'2a')==1
    gam=(2+sqrt(2))/2;
    invA=Ix/(Ix+fdt*gam*A);
    k1=invA*un;
    k2=invA*(un+(sqrt(2)/2)*fdt*A*k1);
    val=k2;
end
if strcmp(flag_SDIRK,'2b')==1
    gam=(3+sqrt(3))/6;
    invA=Ix/(Ix+fdt*gam*A);
    k1=invA*un;
    k2=invA*(un+(sqrt(3)/3)*fdt*A*k1);
    val=un-0.5*fdt*A*(k1+k2);
end
end
  