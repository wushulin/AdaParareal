clc;
clear;
Kmax=40;
Tol=1e-12;
T=100;
cdt=1; lambda=40;
Nt=T/cdt;
u0=random('unif',-2,2,1,1);
U_Ini=random('unif',-2,2,1,Nt+1);
U_Ini(:,1)=u0;
gam=0.158983899988676;
Af_3b=[gam,0,0;
    (1-gam)/2,gam,0;
    (-6*gam^2+16*gam-1)/4,(6*gam^2-20*gam+5)/4,gam];
bf_3b=[(-6*gam^2+16*gam-1)/4,(6*gam^2-20*gam+5)/4,gam];
%---parareal using F=SDIRK3(b): non-uniform----
Uk=U_Ini;
Uk1=Uk;
Err_3b_non_uniform=zeros(1,Kmax);
fdtt=[0.5118,   0.0013,   0.0054,    0.4788,    0.0027]; % non-uniform fine step-sizes
J=length(fdtt);
U_ref_3b_non_uniform=zeros(1,Nt+1);
U_ref_3b_non_uniform(:,1)=u0;
for n=1:Nt
    w0=U_ref_3b_non_uniform(n);
    for p=1:J
        zf=fdtt(p)*lambda;
        w0=((1-zf*bf_3b*inv(eye(3)+zf*Af_3b)*ones(3,1)))*w0;
    end
    U_ref_3b_non_uniform(n+1)=w0;
end
k=1;
Err_3b_non_uniform(k)=norm(Uk1-U_ref_3b_non_uniform,inf);
fprintf('---------non-uniform: %d-th iteration, error=%2.13f--------\n',k,Err_3b_non_uniform(k));
for k=1:Kmax
    Fk=zeros(1,Nt+1);
    for n=1:Nt
        z0=Uk(n);
        for p=1:J
            zf=fdtt(p)*lambda;
            z0=((1-zf*bf_3b*inv(eye(3)+zf*Af_3b)*ones(3,1)))*z0; 
        end
        Fk(n+1)=z0; 
    end
    for n=1:Nt
        Uk1(n+1)=(Uk1(n)-Uk(n))/(1+cdt*lambda)+Fk(n+1);
    end
    Err_3b_non_uniform(k+1)=norm(Uk1-U_ref_3b_non_uniform,inf);
    Uk=Uk1;
    fprintf('---------non-uniform: %d-th iteration, error=%2.13f--------\n',k+1,Err_3b_non_uniform(k+1));
    if Err_3b_non_uniform(k+1)<=Tol
        break;
    end
end
It_Num_3b_non_uniform=k+1;

%---parareal using F=SDIRK3(b): uniform----
Uk=U_Ini;
Uk1=Uk;
Err_3b_uniform=zeros(1,Kmax);
U_ref_3b_uniform=zeros(1,Nt+1);
U_ref_3b_uniform(:,1)=u0;
fdt=cdt/J;
for n=1:Nt
    w0=U_ref_3b_uniform(n);
    for p=1:J
        zf=fdt*lambda;
        w0=((1-zf*bf_3b*inv(eye(3)+zf*Af_3b)*ones(3,1)))*w0;
    end
    U_ref_3b_uniform(n+1)=w0;
end
k=1;
Err_3b_uniform(k)=norm(Uk1-U_ref_3b_uniform,inf);
fprintf('---------uniform: %d-th iteration, error=%2.13f--------\n',k,Err_3b_uniform(k));
for k=1:Kmax
    Fk=zeros(1,Nt+1);
    for n=1:Nt
        z0=Uk(n);
        for p=1:J
            zf=fdt*lambda;
            z0=((1-zf*bf_3b*inv(eye(3)+zf*Af_3b)*ones(3,1)))*z0; 
        end
        Fk(n+1)=z0; 
    end
    for n=1:Nt
        Uk1(n+1)=(Uk1(n)-Uk(n))/(1+cdt*lambda)+Fk(n+1);
    end
    Err_3b_uniform(k+1)=norm(Uk1-U_ref_3b_uniform,inf);
    Uk=Uk1;
    fprintf('---------uniform: %d-th iteration, error=%2.13f--------\n',k+1,Err_3b_uniform(k+1));
    if Err_3b_uniform(k+1)<=Tol
        break;
    end
end
It_Num_3b_uniform=k+1;


semilogy(1:It_Num_3b_non_uniform,Err_3b_non_uniform(1:It_Num_3b_non_uniform),'r-o',...
    1:It_Num_3b_uniform,Err_3b_uniform(1:It_Num_3b_uniform),'b--s',...
    'linewidth',1,'markersize',9);shg
set(gca,'fontsize',13,'fontname','times new roman');
xlabel('Iteration Index $k$','interpreter','latex','fontsize',19);
ylabel('Error','interpreter','latex','fontsize',19);
set(gca,'ytick',10.^(-12:2:0));
ylim([Tol,2]);
title('$\mathcal{F}$=SDIRK3(b)','interpreter','latex','fontsize',20);
leg=legend('non-uniform','uniform');
set(leg,'interpreter','latex','fontsize',14);
xlim([1,13]);
