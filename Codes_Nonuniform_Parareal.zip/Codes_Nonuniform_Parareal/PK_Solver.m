function [res,iter,z0]=PK_Solver(z0,u0,tA,PK_Num,PK_Tol,c)
% u0 is the solution at previous time point t=tn
% z0 is the initial value of PK iteration
% tA=tau*A or tau*A
% tau=DT or dt
% PK_Tol=PK_Tol_G or PK_Tol_F
Nx=length(u0);
Ix=eye(Nx);
e=ones(Nx,1);
for iter=1:PK_Num % loop for PK iteration
    z0=(Ix+(diag(e+c*abs(z0).^2)\tA))\u0; % PK iteration for u1+td*u1./(e+c*u1.^2)=u0;
    res=norm(z0+tA*z0./(e+c*abs(z0).^2)-u0,inf);
    if res<=PK_Tol
        break;
    end
end