clc;
clear;
PK_Num=100; % maximal PK ieration number
Kmax=50; % maximal parareal iteration number
PK_Tol=1e-8; % tolerance for PK iteration (inner loop)
Tol=1e-12; % tolerance for parareal iteration (outer loop)
DT=1/8;
J=16;
dt=DT/J;
T=4;
Nt=T/DT;
h=1/64;
x=(-1:h:1)';
t=0:DT:T;
Nx=length(x);
Ix=speye(Nx);
e=ones(Nx,1);
A=spdiags([-e,2*e,-e]/h^2,[-1,0,1],Nx,Nx);
A(1,Nx)=-1/h^2;
A(Nx,1)=-1/h^2;
U0=exp(-30*x.^2);% initial-value at t=0
U_ref=zeros(Nx,Nt+1); % store the reference solution computed by Backward-Euler
U_ref(:,1)=U0;
PK_Iter=zeros(1,Nt); % store the maximal PK iteration number for Nt coarse time intervals
PK_Iter_n=zeros(1,J); % store PK iteration number for each fine time step at the n-th coarse time interval
for n=1:Nt
    u0=U_ref(:,n);
    for j=1:J
        z0=u0; % initial guess for PK itertaion
        for p=1:PK_Num % loop for PK iteration
            z0=(Ix+dt*(diag(e+z0.^2)\A))\u0; % PK iteration for u1+dt*A*u1./(e+u1.^2)=u0;
            res=norm(z0+dt*A*z0./(e+z0.^2)-u0,inf);
            if res<=PK_Tol
                break;
            end
        end
        PK_Iter_n(j)=p;
        % after this iteration we get solution u1 at the second 'fine' time
        % grid. We store u1 by u0 as well
        u0=z0;
    end
    U_ref(:,n+1)=u0;
    PK_Iter(n+1)=max(PK_Iter_n);
    fprintf('maximal PK iteration number for %d-th coarse time interval is %d\n',n,PK_Iter(n+1));
end    

Uk=zeros(Nx,Nt+1);
Uk1=zeros(Nx,Nt+1);
Uk(:,1)=U0;
Uk1(:,1)=U0;
PK_Iter_k=zeros(Kmax,Nt);
for k=1:Kmax
    Fk=zeros(Nx,Nt+1);
    for n=1:Nt % parallelism for parareal
        u0=Uk(:,n);
        for j=1:J
            z0=u0; % initial guess for PK itertaion
            for p=1:PK_Num % loop for PK iteration
                z0=(Ix+dt*(diag(e+z0.^2)\A))\u0; % PK iteration for u1+dt*A*u1./(e+u1.^2)=u0;
                res=norm(z0+dt*A*z0./(e+z0.^2)-u0,inf);
                if res<=PK_Tol
                    break;
                end
            end
            PK_Iter_n(j)=p;
            u0=z0;
        end
        Fk(:,n+1)=u0;
        PK_Iter_k(k,n)=max(PK_Iter_n); % maximal PK iteraton number for computing Fk at t=Tn over J fine steps
    end
    
    for n=1:Nt % coarse grid correction
        z0=zeros(Nx,1); % initial guess for PK itertaion
        for p=1:PK_Num % loop for PK iteration
            z0=(Ix+DT*(diag(e+z0.^2)\A))\(Uk1(:,n)-Uk(:,n)); % PK iteration for u1+dt*A*u1./(e+u1.^2)=u0;
            res=norm(z0+DT*A*z0./(e+z0.^2)-(Uk1(:,n)-Uk(:,n)),inf);
            if res<=PK_Tol
                break;
            end
        end
        Uk1(:,n+1)=z0+Fk(:,n+1);
        PK_Iter_k(k,n)=PK_Iter_k(k,n)+p; % PK iteraton number for computing Gk at t=Tn
        fprintf('%d-th parareal: maximal PK iteration number for %d-th coarse time interval is %d\n',k,n,PK_Iter_k(k,n));
    end
    err(k)=max(max(abs(Uk1-U_ref)));
    fprintf('************ %d-th parareal: global error is %2.15f ************\n',k,err(k));
    if err(k)<=Tol
        break;
    else 
        Uk=Uk1;
    end
        
end

























































































































































































































































































































mesh(t,x,U_ref);shg