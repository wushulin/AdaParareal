clc;
clear;
%------------------Problem-------------------
%     u_t-u_{xx}/(1+c*u^2)=0
%-----------------------------------------------
PK_Num_G=3; % maximal PK ieration number (G-propagator)
PK_Num_F=6; % maximal PK ieration number (F-propagator)
Kmax=50; % maximal parareal iteration number
PK_Tol_F=1e-4; % tolerance for PK iteration (F-propagator)
PK_Tol_G=1e-2; % tolerance for PK iteration (G-propagator)
Tol=PK_Tol_F;    % tolerance for parareal iteration (outer loop)
c=100;
T=4;
h=1/128;
x=(-1:h:1)';
Nx=length(x);
Ix=speye(Nx);
e=ones(Nx,1);
A=spdiags([-e,2*e,-e]/h^2,[-1,0,1],Nx,Nx);
A(1,Nx)=A(2,1);
A(Nx,1)=A(1,2);

U0=sign(cos(1.5*pi*x)).*abs(cos(1.5*pi*x)).^0.5;% initial-value at t=0
%--------Generate Initial-Guess and Initial-Coarse-Grid-----------
 [DT_n,ct,SolU,~,~]=Adaptive_BE(0,T,U0,0.1,A,PK_Num_G,PK_Tol_G,c,1);
%------------Adaptive Parareal----------------
Err=zeros(1,Kmax);
Uk=SolU;
Uk1=SolU;
Nt=length(DT_n);
Jn=zeros(1,Nt); % number of fine time steps within the n-th coarse interval
dt_Jn=zeros(Nt,30); %value of  fine time steps within the n-th coarse interval
% (each coarse interval contains at most 1000 fine time steps)
PK_Iter_G=zeros(Kmax,Nt); % store PK iteration number for the n-th coarse interval
PK_Res_G=zeros(Kmax,Nt); % store PK residual for the n-th coarse interval
PK_Iter_F=zeros(Kmax,Nt); % store (maximal)PK iteration number for the n-th coarse interval
PK_Res_F=zeros(Kmax,Nt); % store (maximal)PK residual for the n-th coarse interval
Fk=zeros(Nx,Nt+1);
RefU=zeros(Nx,Nt+1);
RefU(:,1)=U0;
for n=1:Nt
    Tn=ct(n);
    Tn1=ct(n+1);
    [dt,~,Un,~,~]=Adaptive_BE(Tn,Tn1,SolU(:,n),DT_n(n)/2,A,PK_Num_F,PK_Tol_F,c,0);
    Fk(:,n+1)=Un(:,end);
    Jn(n)=length(dt);
    dt_Jn(n,1:Jn(n))=dt;
    [~,~,Un,~,~]=Adaptive_BE(Tn,Tn1,RefU(:,n),DT_n(n)/2,A,PK_Num_F,PK_Tol_F,c,0);
    RefU(:,n+1)=Un(:,end);
end
dt_Jnk=dt_Jn;
Jnk=Jn;
Uk(:,2)=Fk(:,2);
Uk1(:,2)=Fk(:,2);
for k=1:Kmax
    for n=k+1:Nt
        [res_G,iter_G,Gk]=PK_Solver(zeros(Nx,1),Uk1(:,n)-Uk(:,n),DT_n(n)*A,PK_Num_G,PK_Tol_G,c);
         PK_Res_G(k,n)=res_G;
         PK_Iter_G(k,n)=iter_G;
        Uk1(:,n+1)=Gk+Fk(:,n+1);
    end
    Err(k)=max(max(abs(Uk1-Uk)));
    fprintf('%d-th parareal iteration: error=%2.15f\n',k,Err(k));
    if Err(k)<=Tol
        break;
    else
        for n=k+1:Nt
            res_F=zeros(1,Jn(n));
            iter_F=zeros(1,Jn(n));
            flag_StepsizeRejection=0;
            z0=Uk1(:,n);
            for j=1:Jnk(n)
                [res,iter,z0]=PK_Solver(z0,z0,dt_Jnk(n,j)*A,PK_Num_F,PK_Tol_F,c);
                res_F(j)=res;
                iter_F(j)=iter;
                if res>PK_Tol_F
                    flag_StepsizeRejection=1;
                    break;
                end
            end
            if flag_StepsizeRejection==0
                Fk(:,n+1)=z0;
                PK_Res_F(k,n)=max(res_F); 
                PK_Iter_F(k,n)=max(iter_F); 
            else
                Tn=ct(n);
                Tn1=ct(n+1);
                 [dt,t,Un,res_max,it_max]=Adaptive_BE(Tn,Tn1,Uk1(:,n),DT_n(n)/2,A,PK_Num_F,PK_Tol_F,c,0);
                Fk(:,n+1)=Un(:,end);
                Jnk(n)=length(dt);
                dt_Jnk(n,1:Jnk(n))=dt;
                PK_Res_F(k,n)=res_max; 
                PK_Iter_F(k,n)=it_max;  
            end
        end
        Uk=Uk1;
    end
end
figure(1)
semilogy(1:k,Err(1:k),'m-+','linewidth',2);
figure(2);
PK_Iter_G_max=zeros(1,Nt);
PK_Res_G_max=zeros(1,Nt);
PK_Iter_F_max=zeros(1,Nt);
PK_Res_F_max=zeros(1,Nt);
for n=1:Nt
    PK_Iter_G_max(n)=max(PK_Iter_G(:,n));
    PK_Res_G_max(n)=max(PK_Res_G(:,n));
    PK_Iter_F_max(n)=max(PK_Iter_F(:,n));
    PK_Res_F_max(n)=max(PK_Res_F(:,n));
end
subplot(1,2,1)
plot(2:Nt,PK_Iter_G_max(2:Nt),'r:o',2:Nt,PK_Iter_F_max(2:Nt),'b:o',2:Nt,ones(1,Nt-1)*PK_Num_G,'r',2:Nt,ones(1,Nt-1)*PK_Num_F,'b');
shg;
xlim([1,Nt]);
ylim([0,1+PK_Num_F]);
subplot(1,2,2)
semilogy(2:Nt,PK_Res_G_max(2:Nt),'r:o',2:Nt,PK_Res_F_max(2:Nt),'b:o',...
    2:Nt,ones(1,Nt-1)*PK_Tol_G,'r',2:Nt,ones(1,Nt-1)*PK_Tol_F,'b');
xlim([2,Nt]);
ylim([min(min(PK_Res_G_max(3:Nt)),min(PK_Res_F_max(2:Nt)))/10,1.4*PK_Tol_G]);

figure(3)
mesh(ct,x,abs(RefU-Uk));shg
